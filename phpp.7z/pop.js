const popup = document.getElementById('popup');
const popupButton = document.getElementById('popupButton');

// Your if condition logic
const isConditionTrue = true;

function openPopup() {
    popup.style.display = 'flex';
}

function closePopup() {
    popup.style.display = 'none';
}

function redirect() {
    window.location.href = 'http://localhost/phpp/login.php';
}

// Check the condition and show the popup if it's true
if (isConditionTrue) {
    openPopup();
}

popupButton.addEventListener('click', redirect);
