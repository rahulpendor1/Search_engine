<?php
// Start the session
session_start();
//echo $oo=$_SESSION["otps"];



?>





<html>
    <head>
    <script>
function myFunction() {
  alert("Wrong OTP \nPlease provide correct OTP");
}
</script>
        <link rel="stylesheet" type="text/css" href="login.css">
      
        <title>
forgate password
        </title>
    </head>
    <body>
          <div class="center">
            <h1>
                Enter Details  
            </h1>
            <form action="#" method="POST" autocomplete="off">
            <div class="form">

             <input type="text" name="otp" placeholder="Please enter OTP" class="textbox" 
             style="font-size:15px;">
               
             <input type="submit" name="validate"  value="Validate OTP" class="btn">


                <div class="signup" style="color:blue;"> <a href="login.php" class="link">Login Here
                      
                </a>&nbsp; &nbsp; <a href="signup.php" class="link">Signup Here</a></div>
            </div>
          </div>
        </form>




   

 

<?php
include("connection.php");
      if (isset($_POST['validate']))
        {
        
         $otp11 = $_SESSION["otps"];
         $otp22 = $_POST['otp'];
         if ($otp11==$otp22)
         {

            //echo 'etered otp is same';
            // header('location:change.php'); 
            echo "<script>
            alert('OTP Verification successfully!');
            window.location.href = 'change.php';
        </script>";
        }
         else {
            //echo 'not same ';
            echo '<script>  
            myFunction();
            </script>' ;
         }
        


         }
      

?>






</body>




</html>







