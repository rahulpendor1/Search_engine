<?php
// Start the session
session_start();
?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="login.css">
      
        <title>
forgate password
        </title>
    </head>
    <body>
          <div class="center">
            <h1>
                Enter Details  
            </h1>
            <form action="#" method="POST" autocomplete="off">
            <div class="form">
                <input type="text" name="pass1" required placeholder="Please new password" 
                class="textbox" style="font-size:15px;">

             <input type="text" name="pass2" placeholder="Please confirm new password" class="textbox" 
             style="font-size:15px;">
               
             <input type="submit" name="change"  value="Change password" class="btn">
                <div class="signup" style="color:blue;"> <a href="login.php" class="link">Login Here
                      
                </a>&nbsp; &nbsp; <a href="signup.php" class="link">Signup Here</a></div>
            </div>
          </div>
        </form>




   

 

<?php
include("connection.php");
      if (isset($_POST['change']))
      {
        
         $pass11 = $_POST['pass1'];
         $pass22 = $_POST['pass2'];
         if ($pass11==$pass22)
         {
        $dda=$_SESSION["username"];
        echo $dda;
         
        $sql = "UPDATE info SET password='$pass11' WHERE username='$dda'";
        if ($conn->query($sql) === TRUE) {
          //echo "Record updated successfully"; 
          header('location:popup.php');
         
      
        } else {
          echo "Error updating record: " . $conn->error;
        }
        


    }
      }

?>
 </script>





</body>




</html>