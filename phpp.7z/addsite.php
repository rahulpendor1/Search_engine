<html>
    <head>


        <style>
   input{
    width: 100%;
    height: 40px;
    border: 1px solid green;
    border-radius: 10px;
   }

   #subbtn{
    width: 40%;
    height: 50px;
    border: 1px solid green;
    border-radius: 10px;
    background-color: white;
    color: green;
    font-size: 18px;
   }
   #subbtn:hover{
    background-color: green;
    color: white;
   }

   #rebtn{
    width: 40%;
    height: 50px;
    border: 1px solid rgb(250, 0, 0);
    border-radius: 10px;
    background-color: white;
    color: red;
    font-size: 18px;
   }
   #rebtn:hover{
    background-color: red;
    color: white;
   }
#text{
    width: 100%;
    height: 100px;
    border-radius: 10px;
    border: 1px solid 
    green;
}
#img{
    border: 0px;
    width: 100%;
}

td{
    font-size: 20px;
}
#body{
    background-image: url("add.jpg");
            background-repeat: no-repeat;
            background-position: center center;
            background-attachment: fixed;
            background-size: cover;
            height: 100vh;
            width: 100%;
            margin: 0;
            padding: 0;}
	


        

        </style>

    </head>
<body id=body >
    <font size="7"><b><p align="center">Add a Website</p></b></font> 
    <form action="" method="post" enctype="multipart/form-data" autocomplete="off">
        <table border="0" width="75%" align="center" cellspacing="10" >
            <tr>
                <td>Website Title</td>
                <td> <input type="text" name="websitetitle" id=""> </td>
<tr>
                <td>Website Link</td>
                <td> <input type="text" name="websitelink" id=""> </td>
                <tr>
                <td>Website Keywords</td>
                <td> <input type="text" name="websitekeyword" id=""> </td>
                <tr>
                <td>Website Description</td>
                <td> <textarea name="websitedesc" id="text"></textarea></td>
                <tr>
                <td>Website Image</td>
                <td> <input type="file"  name="websiteimage" id="img"> </td>
                <tr><br><br>
               
                <td colspan="2"align="center" ><br><br> <input  type="submit" value="Add Website" name="addwebsite" id="subbtn"> &nbsp; &nbsp;
                <input type="reset" name="reset" id="rebtn"> 
            </tr>
        </table>




    </form>
</body>


</html>

<?php
     include("connection.php");
     error_reporting(0);
     
     if($_POST['addwebsite'])
{
    $website_title= $_POST['websitetitle'];

    $website_link= $_POST['websitelink'];

    $website_keyw= $_POST['websitekeyword'];

    $website_desc= $_POST['websitedesc'];

    $filename= $_FILES["websiteimage"] ["name"];
    
    $tempname= $_FILES["websiteimage"] ["tmp_name"];
    $folder= "website_images/".$filename ;
    move_uploaded_file($tempname, $folder);

    if ($website_title!=""&&$website_link!=""&&$website_keyw!=""&&$website_desc!=""&&$filename!="")
    {
        $query= "INSERT INTO addwebsite VALUES ('','$website_title','$website_link','$website_keyw','$website_desc','$folder')";
        $data=mysqli_query($conn,$query);


        if ($data)
        {
            echo "<script>alert('website_inserted')</script>";

        }
        
    }
    else
        {
            echo "<script>alert('failed')</script>";
        }


}

?>