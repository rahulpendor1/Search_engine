<?php
// Start the session
session_start();
//echo $oo=$_SESSION["otps"];
echo $_SESSION["mobc"];


$box1=$_SESSION["namec"];
$box2=$_SESSION["mobc"];
$box3=$_SESSION["emailc"];
$box4=$_SESSION["userc"];
$box5=$_SESSION["passc"];


?>





<html>
    <head>
    <style>

body.modal-open {
    overflow: hidden;
  }

  #overlay {
    display: none; /* Hidden by default */
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    backdrop-filter: blur(5px); /* Background blur */
    background: rgba(0, 0, 0, 0.2); /* Slight dark tint */
    z-index: 999; /* Below modal */
  }

  /* Modal styling */
  #mymodal {
    display: none; /* Hidden by default */
    position: fixed;
    top: 20%;
    left: 50%;
    transform: translate(-50%, -20%);
    background: #fff;
    padding: 20px 30px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    border-radius: 10px;
    text-align: center;
    z-index: 1000; /* Above overlay */
  }

  #mymodal button {
    padding: 10px 20px;
    background-color: #007BFF;
    border: none;
    color: #fff;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
  }

  #mymodal button:hover {
    background-color: #0056b3;
  
  }
</style>
    <script>
function myFunction() {
  alert("Wrong OTP \nPlease provide correct OTP");

  
}
function signsuccess() {
  document.getElementById("overlay").style.display = "block";
  document.getElementById("mymodal").style.display = "block";

  // Optionally prevent scrolling
  document.body.classList.add('modal-open');

  
}


</script>
        <link rel="stylesheet" type="text/css" href="login.css">
      
        <title>
 validate OTP
        </title>
    </head>
    <body>
    <div id="overlay"></div>

    <div id="mymodal">
  <a href="login.php"><button>Visit Page Now</button></a>
</div>






          <div class="center">
            <h1>
                Enter Email OTP  
            </h1>
            <form action="#" method="POST" autocomplete="off">
            <div class="form">

             <input type="text" name="otp" placeholder="Please enter OTP" class="textbox" 
             style="font-size:15px;">
               
             <input type="submit" name="validate"  value="Validate OTP" class="btn">


                <div class="signup" style="color:blue;"> <a href="login.php" class="link">Login Here
                      
                </a>&nbsp; &nbsp; <a href="signup.php" class="link">Signup Here</a></div>
            </div>
          </div>
        </form>




   

 

<?php
include("connection.php");
      if (isset($_POST['validate']))
        {
        
         $otp11 = $_SESSION["otps"];
         $otp22 = $_POST['otp'];
         if ($otp11==$otp22)
         {

            //echo 'etered otp is same';
            //header('location:sign_after_otp.php'); 

            $st1r="INSERT INTO `info` (`sr`,`name`, `mobile`, `email`, `username`, `password`) VALUES ('','$box1', '$box2', '$box3','$box4', '$box5');";
            $r1r=mysqli_query($conn, $st1r);
            if ($r1r){
           // echo"Singup Sucessful";
           //header('location:login.php');
           echo "<script>
           alert('registration successfull!');
           window.location.href = 'login.php';
            </script>";
            }
            else{
               echo "Singup Failed";
            }





        }
         else {
            //echo 'not same ';
            echo '<script>  
            myFunction();
            </script>' ;
         }
        


         }
      

?>






</body>




</html>







