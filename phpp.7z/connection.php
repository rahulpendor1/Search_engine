<?php 

      $servername="localhost";
      $username="root";
      $password="";
      $dbname="searche";


      $conn=mysqli_connect($servername,$username,$password,$dbname);
      if($conn)
      {
        //echo "connection success";

      }
      else
      {
        //die ("connection faild".mysqli_connect_error());
      }




?>