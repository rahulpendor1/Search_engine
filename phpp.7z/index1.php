<!DOCTYPE html>
<html>
<head>
    <title>SSCET Search</title>
    <style>
        #body {
            background-image: url("ab.jpg");
            background-repeat: no-repeat;
            background-position: center center;
            background-attachment: fixed;
            background-size: cover;
            height: 100vh;
            width: 100%;
            margin: 0;
            padding: 0;
        }

        #cpanel {
            text-decoration: none;
            color: white;
            margin-left: 5%;
        }

        #cpanel:hover {
            color: lightblue;
        }

        #searchbox {
            border-radius: 10px;
            padding: 10px;
            width: 80%;
            max-width: 300px;
            height: 30px;
            border: 3px solid white;
            background-color: transparent;
            color: white;
            font-size: 20px;
        }

        #searchbtn {
            color: white;
            border: 1px solid whitesmoke;
            border-radius: 10px;
            width: 80%;
            max-width: 200px;
            height: 40px;
            background-color: #d9b6f0;
            font-size: 20px;
        }

        #searchbtn:hover {
            background-color: blue;
            color: white;
        }

        #searchbox:hover {
            background-color: #B5A4A4;
            color: black;
        }

        @media (max-width: 768px) {
            #searchbox {
                width: 90%;
            }

            #searchbtn {
                width: 90%;
            }
        }

        /* Style for label text */
        .search-label {
            color: white;
            font-size: 24px;
            text-align: center;
        }
    </style>
</head>
<body id="body">
    <br><br><br>
    <a id="cpanel" href="login.php" style="color:red;">CPANEL</a>
    <br><br><br><br><br><br><br><br><br><br><br><br>

    <!-- Label above the search box -->
    <center><div class="search-label">Search Here</div></center>
    <form action="result.php" method="GET">
        <center><input id="searchbox" type="text" name="searchbo" autocomplete="off"></center><br>
        <center><input id="searchbtn" type="submit" name="searchbt" value="Search"></center>
    </form>
</body>
</html>
