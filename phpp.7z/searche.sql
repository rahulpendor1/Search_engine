-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 29, 2023 at 12:43 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `searche`
--

-- --------------------------------------------------------

--
-- Table structure for table `addwebsite`
--

CREATE TABLE `addwebsite` (
  `id` int(10) NOT NULL,
  `websitetitle` varchar(100) NOT NULL,
  `websitelink` varchar(100) NOT NULL,
  `websitekeyword` varchar(50) NOT NULL,
  `websitedesc` varchar(500) NOT NULL,
  `websiteimage` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addwebsite`
--

INSERT INTO `addwebsite` (`id`, `websitetitle`, `websitelink`, `websitekeyword`, `websitedesc`, `websiteimage`) VALUES
(1, 'gdgggg', 'regerger', 'rahul', 'hrhh', '/home/dikshant/Pictures/11.png'),
(2, 'hdfgg', 'dfsdf', 'fsfs', 'fsdfsfsfs', 'website_images/Screenshot (1).png'),
(3, 'Government Polytechnic | Amravati', 'https://www.gpamravati.ac.in/', 'gpa , GPA , govt poly amravati', 'Government Polytechnic, Amravati is an autonomous Institute of Govt. Polytechnic, Maharashtra established in the year 1955. This institute has a long ...', 'website_images/2018-06-16.jpg'),
(4, 'Government Polytechnic, Amravati: Admission, Fees ...', 'https://www.careers360.com/colleges/government-polytechnic-amravati', 'gpa , GPA , govt poly amravati', 'Government Polytechnic, Amravati ; Estd. Year: 1955 ; Total Faculty: 85 ; Total Students Enrollment: 1808 ; Browse by Courses · D.Pharma. Total Fees: 21.16 K · Seats: ...\r\nTotal Students Enrollment: 1808\r\nTotal Faculty: 85\r\nEstd. Year: 1955\r\nBrowse by Courses: D.Pharma: Total Fee', 'website_images/2020-10-12.jpg'),
(5, 'Government Polytechnic, Amravati - Admissions, Contact ...', 'https://collegedunia.com/college/26451-government-polytechnic-amravati', 'gpa , GPA , govt poly amravati', 'Government Polytechnic, Amravati · Diploma in Leather Goods & Accessories Design · Diploma in Pharmacy [D. · Diploma in Civil Engineering · Diploma in Computer ...\r\n Rating: 9.3/10 · ‎2 reviews\r\n', 'website_images/2022-06-19.jpg'),
(6, 'Government Polytechnic, Amravati - Admissions, Contact ...', 'https://collegedunia.com/college/26451-government-polytechnic-amravati', 'gpa , GPA , govt poly amravati', 'Government Polytechnic, Amravati · Diploma in Leather Goods & Accessories Design · Diploma in Pharmacy [D. · Diploma in Civil Engineering · Diploma in Computer ...\r\n Rating: 9.3/10 · ‎2 reviews\r\n', 'website_images/2022-06-19.jpg'),
(7, 'Facebook - log in or sign up', 'https://www.facebook.com/', 'fb , facebook', 'Create an account or log into Facebook. Connect with friends, family and other people you know. Share photos and videos, send messages and get updates.', 'website_images/download.png'),
(8, 'instagram', 'https://www.instagram.com/', 'insta', 'Create an account or log in to Instagram - A simple, fun & creative way to capture, edit & share photos, videos & messages with friends & family.\r\n', 'website_images/download (1).png'),
(9, 'telegram', 'https://telegram.org/', 'telegram', 'Telegram delivers messages faster than any other application. Powerful. Telegram has no limits on the size of your media and chats.', 'website_images/telegram -.html'),
(10, 'yahoo baba', 'https://in.yahoo.com', 'yahho', 'As of August 26th, 2021 Yahoo India will no longer be publishing content. Your Yahoo Account, Mail and Search experiences will not be affected in any way ...\r\n', 'website_images/yahoo -.html'),
(11, 'Spacewood - Modular Kitchens, Wardrobes, Interior ...', 'https://spacewood.in/', 'spacewood , sos', 'Spacewood is Indias leading premium brand and manufacturer of Modular Furniture. We are a one stop solution for home and office needs.', 'website_images/sos1.jpg'),
(12, 'Spacewood Office Solutions', 'https://sosoffice.in/', ' 	spacewood , sos', '... Spacewood Office Solution Pvt Ltd. SZ-13, Butibori MIDC, Nagpur- 441122. +91 7103297601 / 7103297602. sos@spacewood.in. Follow. Linkedin youtube Instagram ...', 'website_images/sos2.jpg'),
(13, 'Career - Spacewood Office Solutions', 'https://www.sosoffice.in/Career', ' spacewood , sos', 'At Spacewood Office Solutions, we believe creativity begins with innovation and inquisitiveness. ... Butibori MIDC, Nagpur- 441122. +91 7103297601 / 7103297602.', 'website_images/sos3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `sr` int(10) NOT NULL,
  `name` varchar(55) NOT NULL,
  `mobile` varchar(44) NOT NULL,
  `email` varchar(55) NOT NULL,
  `username` varchar(55) NOT NULL,
  `password` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`sr`, `name`, `mobile`, `email`, `username`, `password`) VALUES
(1, 'rahul', '7775851840', 'salamd2030@gmail.com', 'rahul123', '123'),
(2, 'karan', '4753666767', 'karan@gamil.com', 'karan123', 'karan123'),
(3, 'a', 'a', 'a', 'a', 'aa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addwebsite`
--
ALTER TABLE `addwebsite`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`sr`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addwebsite`
--
ALTER TABLE `addwebsite`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `sr` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
