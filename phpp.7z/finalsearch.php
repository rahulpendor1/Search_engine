<html>
    <head>
        <title>

        </title>

        <link rel="stylesheet" type="text/css" href="finals.css">
    </head>
    <body>
      <br><br>
        <table border="0" width="60%" style="margin-left:100px;">
            <?php
 
                  $query1= "select * from addwebsite where websitekeyword like '%$search%' ";
                  $data1=mysqli_query($conn, $query1);
                  while($row1=mysqli_fetch_array($data1))
                  {  
                    echo "
                          <tr>
                          <td>
                          <font size='5.5'><b> <a href='$row1[2]'> $row1[1]</b></a> </font>";

                          echo "  <tr> <td><font size='4.5' color='green'>  $row1[2] </font>";

                          echo "<tr><td><font size='4' color=''>  $row1[4] </font><br><br>

                    </td></tr>
                    ";
                  }


            ?>
        </table>


    </body>
</html>