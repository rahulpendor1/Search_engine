<?php
// Start the session
session_start();
?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="login.css">
        <title>Forgot Password</title>
    </head>
    <body>
        <div class="center">
            <h1>Enter Details</h1>
            <form action="#" method="POST" autocomplete="off">
                <div class="form">
                    <!-- <input type="text" name="mob" required placeholder="Please confirm your Mobile" 
                        class="textbox" style="font-size:15px;"> -->
                    <input type="text" name="f2" required placeholder="Please confirm your email" 
                        class="textbox" style="font-size:15px;">
                    <input type="submit" name="forgot"  value="login" class="btn">
                    <div class="signup" style="color:blue;">
                        <a href="login.php" class="link">Login Here</a>&nbsp; &nbsp;
                        <a href="sign.php" class="link">Signup Here</a>
                    </div>
                </div>
            </form>
        </div>
    </body>
</html>

<?php
include("connection.php");
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'C:/xampp/htdocs/phpp/composer/vendor/phpmailer/phpmailer/src/Exception.php';
require 'C:/xampp/htdocs/phpp/composer/vendor/phpmailer/phpmailer/src/PHPMailer.php';
require 'C:/xampp/htdocs/phpp/composer/vendor/phpmailer/phpmailer/src/SMTP.php';

if (isset($_POST['forgot'])) {
    $email = trim($_POST['f2']);
    $mob = trim($_POST['mob']);

    // Check if email exists in the database using MySQLi
    $stmt = $conn->prepare("SELECT * FROM info WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        // Email not registered
        echo "<script>alert('This email is not registered with us or Invalid Email.');</script>";
        exit();
    }

    // Email is registered, generate OTP
    $randomNumber = rand(100000, 999999);
    $_SESSION["username"] = $email;
    $_SESSION["mobile"] = $mob;  // Still storing mobile in session if needed
    $_SESSION["otps"] = $randomNumber;

    $to = $email;
    $subject = "Verification";
    $message = "Your one time OTP is: $randomNumber";

    // Send the OTP
    echo smtp_mailer($to, $subject, $message);

    $stmt->close();
}

function smtp_mailer($to, $subject, $msg) {
    $mail = new PHPMailer(); 
    $mail->IsSMTP(); 
    $mail->SMTPAuth = true; 
    $mail->SMTPSecure = 'tls'; 
    $mail->Host = "smtp.gmail.com";
    $mail->Port = 587; 
    $mail->IsHTML(true);
    $mail->CharSet = 'UTF-8';
    // $mail->SMTPDebug = 2; 
    $mail->Username = "pendorr2@gmail.com";
    $mail->Password = "khpr wtfz ujcu jvmf";
    $mail->SetFrom("pendorr2@gmail.com");
    $mail->Subject = $subject;
    $mail->Body = $msg;
    $mail->AddAddress($to);
    $mail->SMTPOptions = array('ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => false
    ));

    if ($mail->Send()) {
        echo "<script>
        alert('OTP sent successfully!');
        window.location.href = 'sent.php';
    </script>";
    exit();
        
      
        // header('location:sent.php');
    } else {
        echo "<script>alert('Failed to send email. Please provide your correct email address.');</script>";
        echo $mail->ErrorInfo;
    }
}
?>
