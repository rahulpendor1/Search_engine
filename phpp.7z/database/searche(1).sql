-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 19, 2023 at 10:30 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `searche`
--

-- --------------------------------------------------------

--
-- Table structure for table `addwebsite`
--

CREATE TABLE `addwebsite` (
  `id` int(10) NOT NULL,
  `websitetitle` varchar(100) NOT NULL,
  `websitelink` varchar(100) NOT NULL,
  `websitekeyword` varchar(50) NOT NULL,
  `websitedesc` varchar(500) NOT NULL,
  `websiteimage` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `addwebsite`
--

INSERT INTO `addwebsite` (`id`, `websitetitle`, `websitelink`, `websitekeyword`, `websitedesc`, `websiteimage`) VALUES
(3, 'Government Polytechnic | Amravati', 'https://www.gpamravati.ac.in/', 'gpa , GPA , govt poly amravati', 'Government Polytechnic, Amravati is an autonomous Institute of Govt. Polytechnic, Maharashtra established in the year 1955. This institute has a long ...', 'website_images/2018-06-16.jpg'),
(4, 'Government Polytechnic, Amravati: Admission, Fees ...', 'https://www.careers360.com/colleges/government-polytechnic-amravati', 'gpa , GPA , govt poly amravati', 'Government Polytechnic, Amravati ; Estd. Year: 1955 ; Total Faculty: 85 ; Total Students Enrollment: 1808 ; Browse by Courses · D.Pharma. Total Fees: 21.16 K · Seats: ...\r\nTotal Students Enrollment: 1808\r\nTotal Faculty: 85\r\nEstd. Year: 1955\r\nBrowse by Courses: D.Pharma: Total Fee', 'website_images/2020-10-12.jpg'),
(5, 'Government Polytechnic, Amravati - Admissions, Contact ...', 'https://collegedunia.com/college/26451-government-polytechnic-amravati', 'gpa , GPA , govt poly amravati', 'Government Polytechnic, Amravati · Diploma in Leather Goods & Accessories Design · Diploma in Pharmacy [D. · Diploma in Civil Engineering · Diploma in Computer ...\r\n Rating: 9.3/10 · ‎2 reviews\r\n', 'website_images/2022-06-19.jpg'),
(6, 'Government Polytechnic, Amravati - Admissions, Contact ...', 'https://collegedunia.com/college/26451-government-polytechnic-amravati', 'gpa , GPA , govt poly amravati', 'Government Polytechnic, Amravati · Diploma in Leather Goods & Accessories Design · Diploma in Pharmacy [D. · Diploma in Civil Engineering · Diploma in Computer ...\r\n Rating: 9.3/10 · ‎2 reviews\r\n', 'website_images/2022-06-19.jpg'),
(7, 'Facebook - log in or sign up', 'https://www.facebook.com/', 'fb , facebook', 'Create an account or log into Facebook. Connect with friends, family and other people you know. Share photos and videos, send messages and get updates.', 'website_images/download.png'),
(8, 'instagram', 'https://www.instagram.com/', 'insta', 'Create an account or log in to Instagram - A simple, fun & creative way to capture, edit & share photos, videos & messages with friends & family.\r\n', 'website_images/download (1).png'),
(9, 'telegram', 'https://telegram.org/', 'telegram', 'Telegram delivers messages faster than any other application. Powerful. Telegram has no limits on the size of your media and chats.', 'website_images/telegram -.html'),
(10, 'yahoo baba', 'https://in.yahoo.com', 'yahho', 'As of August 26th, 2021 Yahoo India will no longer be publishing content. Your Yahoo Account, Mail and Search experiences will not be affected in any way ...\r\n', 'website_images/yahoo -.html');

--
-- Triggers `addwebsite`
--
DELIMITER $$
CREATE TRIGGER `after_delete_addwebsite` AFTER DELETE ON `addwebsite` FOR EACH ROW INSERT INTO log_addwebsite (original_id, websitetitle, websitelink, websitekeyword, websitedesc, websiteimage)
    VALUES (OLD.id, OLD.websitetitle, OLD.websitelink, OLD.websitekeyword, OLD.websitedesc, OLD.websiteimage)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `deleted_info`
--

CREATE TABLE `deleted_info` (
  `sr` int(11) DEFAULT NULL,
  `name` varchar(55) DEFAULT NULL,
  `mobile` varchar(44) DEFAULT NULL,
  `email` varchar(55) DEFAULT NULL,
  `username` varchar(55) DEFAULT NULL,
  `password` varchar(55) DEFAULT NULL,
  `deleted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `deleted_info`
--

INSERT INTO `deleted_info` (`sr`, `name`, `mobile`, `email`, `username`, `password`, `deleted_at`) VALUES
(NULL, NULL, NULL, NULL, NULL, NULL, '2023-11-19 09:06:11'),
(4, 'dad', 'asd', 'da@ds', 'dfsf', 'dfds', '2023-11-19 09:06:17'),
(1, 'rahul', '7775851840', 'rahul@ah', 'rahul123', 'rahul123', '2023-11-19 09:07:06');

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `sr` int(10) NOT NULL,
  `name` varchar(55) NOT NULL,
  `mobile` varchar(44) NOT NULL,
  `email` varchar(55) NOT NULL,
  `username` varchar(55) NOT NULL,
  `password` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`sr`, `name`, `mobile`, `email`, `username`, `password`) VALUES
(5, 'sads', '7775851840', 'rdprdp004@gmail.com', 'rahul123', '123'),
(6, 'ascacaasdasda', '4352452523', 'pendorr2@gmail.com', 'rahul123', '123');

--
-- Triggers `info`
--
DELIMITER $$
CREATE TRIGGER `after_delete` AFTER DELETE ON `info` FOR EACH ROW INSERT INTO deleted_info (sr, name, mobile, email, username, password)
    VALUES (OLD.sr, OLD.name, OLD.mobile, OLD.email, OLD.username, OLD.password)
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `log_addwebsite`
--

CREATE TABLE `log_addwebsite` (
  `log_id` int(11) NOT NULL,
  `original_id` int(11) DEFAULT NULL,
  `websitetitle` varchar(255) DEFAULT NULL,
  `websitelink` varchar(255) DEFAULT NULL,
  `websitekeyword` varchar(255) DEFAULT NULL,
  `websitedesc` varchar(255) DEFAULT NULL,
  `websiteimage` varchar(255) DEFAULT NULL,
  `deleted_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `log_addwebsite`
--

INSERT INTO `log_addwebsite` (`log_id`, `original_id`, `websitetitle`, `websitelink`, `websitekeyword`, `websitedesc`, `websiteimage`, `deleted_at`) VALUES
(1, 11, 'wdw', 'ewwd', 'wdw', 'wdwdw', 'dwdw.ewde', '2023-11-19 09:13:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addwebsite`
--
ALTER TABLE `addwebsite`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`sr`);

--
-- Indexes for table `log_addwebsite`
--
ALTER TABLE `log_addwebsite`
  ADD PRIMARY KEY (`log_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addwebsite`
--
ALTER TABLE `addwebsite`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `sr` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `log_addwebsite`
--
ALTER TABLE `log_addwebsite`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
