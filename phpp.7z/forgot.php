<?php
// Start the session
session_start();
?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="login.css">
        <title>
forgate password
        </title>
    </head>
    <body>
          <div class="center">
            <h1>
                Enter Details
            </h1>
            <form action="#" method="POST" autocomplete="off">
            <div class="form">
                <input type="text" name="f1" required placeholder="Please conform us your username" 
                class="textbox" style="font-size:15px;">

             <input type="text" name="f2" placeholder="Please comform us your email" class="textbox" 
             style="font-size:15px;">
               
             <input type="submit" name="forgot"  value="login" class="btn">
                <div class="signup" style="color:blue;"> <a href="login.php" class="link">Login Here
                      
                </a>&nbsp; &nbsp; <a href="signup.php" class="link">Signup Here</a></div>
            </div>
          </div>
        </form>


    </body>




</html>

<?php
include("connection.php");
      if (isset($_POST['forgot']))
      {
         $ff1 = $_POST['f1'];
         $_SESSION["username"] = "$ff1";
         //echo $_SESSION["username"];
          $ff2 = $_POST['f2'];
         $rd1 = "SELECT * FROM `info` WHERE `username` LIKE '$ff1' AND `email` LIKE '$ff2'";
        $d1=mysqli_query($conn, $rd1);
        $total1=mysqli_num_rows($d1);
        //echo $total;
        if($total1 == 1)
        {
          //   echo "Login ok";
             header('location:changepass.php');

        }
        else {
            echo "login failed";
        }


      }

?>





      

