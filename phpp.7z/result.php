


<html>

<head>
    <title>
Result Page
    </title>
    

<style>

    #searchfild{

        width: 500px;
        height: 35px;
        border-radius: 7px;
        border: 1px solid green;

    }

    
    #gobtn{

width: 100px;
height: 40px;
border-radius: 7px;
border: 1px solid green;
background-color: white;
font-size: 18px;

}

#gobtn:hover{
    background-color: green;
    color: white;
}
</style>
<link rel="stylesheet" type="text/css" href="finals.css">

</head>

<body >
    <form action="" method="get" >
        <table border="0" width="100%" bgcolor="f2f2f2">
            <tr>
                <td width="13%" >
                    <a href="index.php"><img src="searchlogo.png" width="100%"></a>
                </td>
                <td>

                <input type="text"  name="searchbo" id="searchfild" autocomplete="off"  value="<?php $search=$_GET['searchbo']; echo $search; ?>">
                
                    <input type="submit" name="searchbt" value="Go" id="gobtn">
                </td>
            </tr>
        </table><br>




        <table border="0"  style="margin-left:100px;">
            <tr>

<?php
  include("connection.php");
  if(isset($_GET['searchbt']));
  {
    $search=$_GET['searchbo'];
    if($search=="")
    {
        echo " <b>Please write something in search box</b>";
        exit();
    }
    $query= "select * from addwebsite where websitekeyword like '%$search%' limit 0,4 ";
    $data=mysqli_query($conn, $query);
    if(mysqli_num_rows($data)<1)
    {
        echo "<b> No result found </b>";
        exit();
    }

    echo "<a href='#' style='margin-left:105px;'> More images for $search ";
    while($row=mysqli_fetch_array($data))
    {
        echo "   
              <td>
              <img src='$row[5]' width='200px;' >
              </td>  
        ";
    }
  }


?>

</tr>




    </form>

<?php
include("finalsearch.php");
?>
</body>
</html>
   
        