
<?php
session_start();
?>

<html>
    <head>
        <link rel="stylesheet" type="text/css" href="login.css">
        <title>
Admin login
        </title>
    </head>
    <body>

    
          <div class="center">
            <h1>
                login
            </h1>
            <form action="#" method="POST" autocomplete="off">
            <div class="form">
                <input type="text" name="id" placeholder="Username" class="textbox">
             <input type="password" name="pass" placeholder="password" class="textbox">
                <div class="forpass" >
                    <a href="mail.php" class="link">Forgate password</a>

                </div>
             <input type="submit" name="login"  value="login" class="btn">
                <div class="signup"> New Member ? <a href="sign.php" class="link">Signup Here</a></div>
            </div>
          </div>
        </form>


    </body>
</html>
<?php
include("connection.php");
      if (isset($_POST['login']))
      {
         $idname = $_POST['id'];
         $pwd = $_POST['pass'];
         $rd = "SELECT * FROM `info` WHERE `username` = '$idname' AND `password` = '$pwd'";
        $d=mysqli_query($conn, $rd);
        $total=mysqli_num_rows($d);
        echo $total;
        if($total == 1)
        {
             echo "Login ok";

             $_SESSION['username']=$idname;
             header('location:cpanel.php');

        }
        else {
            // echo "login failed";
            echo "<script> alert('User ID or Password Incorrect');</script>";
        }


      }



      


?>