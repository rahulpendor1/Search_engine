<html>

<head>
    <title>Display</title>
    <link rel="stylesheet" type="text/css" href="capanel.css">
    
   

   

   <!-- Include jsPDF and xlsx libraries -->
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.3/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.0/xlsx.full.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>



    <style>
     /* Your existing CSS styles */

/* Navbar styles similar to cPanel */
#navbar {
    background-color: black;
    padding: 10px 0;
    text-align: center;
}

#navbar ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
}

#navbar ul li {
    display: inline;
    margin-right: 20px;
}

#navbar ul li a {
    text-decoration: none;
    color: white;
    font-size: 18px;
}

#navbar ul li a:hover {
    
    color: green;
  
}

table {
    border-collapse: collapse;
    width: 100%;
    margin-top: 20px;
}

table th, table td {
    border: 1px solid #8800c7;
    padding: 10px;
    text-align: center;
}

table th {
    background-color: orange;
    color: white;
}

table tr:hover {
    background-color: #B5A4A4;
}

        body {
            margin: 0;
            padding: 0;
        }

        .maindv {
            margin: 20px;
            padding: 10px;

        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #e1b5ff;
        }

        th,
        td {
            border: 1px solid #000;
            padding: 10px;
            text-align: left;
        }

      

        /* Add these styles to your existing CSS */

#export-buttons {
    margin-top: 20px;
    text-align: center;
}

#export-buttons button {
    background-color: green;
    color: white;
    border: none;
    padding: 10px 20px;
    margin: 0 10px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s ease;
}

#export-buttons button:hover {
    background-color: darkgreen;
}

    </style>
</head>

<body bgcolor="blueviolet">
    <div id="navbar">
        <ul>
            <li><a href="index.php"> Go to the search engine</a></li>
            <li><a href="addsite.php">Add A Website </a></li>
            <li><a href="cpanel.php">Admin Details </a></li>
        </ul>
    </div>
    <div class="maindv">
        <h2>Displaying Uploaded Websites</h2>
        <?php
        include("connection.php");
        // error_reporting(0);

        $qq = "SELECT * FROM `addwebsite`";
        $rr = mysqli_query($conn, $qq);
        $aa = mysqli_num_rows($rr);

        if ($aa != 0) {
        ?>
            <table id="trid">
            <tr>
    <th><input type="text" id="searchTitle" placeholder="Search by Title"></th>
    <th><input type="text" id="searchLink" placeholder="Search by Link"></th>
    <th><input type="text" id="searchKeyword" placeholder="Search by Keyword"></th>
    <th><input type="text" id="searchDesc" placeholder="Search by Description"></th>
    <th><input type="text" id="searchImage" placeholder="Search by Image URL"></th>
</tr>

                
                <tr>
                    <th>Website title</th>
                    <th>Website Link</th>
                    <th>Website keyword</th>
                    <th>Website disc</th>
                    <th>Image URL</th>
                </tr>

                <?php
                while ($result = mysqli_fetch_assoc($rr)) {
                    echo "<tr>
                            <td>" . $result['websitetitle'] . "</td>
                            <td>" . $result['websitelink'] . "</td>
                            <td>" . $result['websitekeyword'] . "</td>
                            <td>" . $result['websitedesc'] . "</td>
                            <td>" . $result['websiteimage'] . "</td>
                        </tr>";
                }
                ?>
            </table>
        <?php
        } else {
            echo "<p>No websites available.</p>";
        }
        ?>
    </div>


      <!-- Export buttons -->
      <div id="export-buttons">
   
        <button id="excel-button">Export to Excel</button>
        <br><br>
    </div>

    <!-- Your existing table and other content -->

    <script>
       
        document.getElementById('excel-button').addEventListener('click', exportToExcel);

        function exportToExcel() {
            const table = document.getElementById('trid'); // Replace 'your-table-id' with your actual table ID
            const ws = XLSX.utils.table_to_sheet(table);
            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
            XLSX.writeFile(wb, 'Websites.xlsx');
        }

        
    $(document).ready(function() {
        // Function to perform search based on input value and column index
        function searchTable(columnIndex, inputElement) {
            var filter, table, tr, td, i, txtValue;
            filter = inputElement.value.toUpperCase();
            table = document.getElementById("trid");
            tr = table.getElementsByTagName("tr");

            for (i = 1; i < tr.length; i++) { // Start from 1 to skip the header row
                td = tr[i].getElementsByTagName("td")[columnIndex];
                if (td) {
                    txtValue = td.textContent || td.innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }

        // Attach keyup event listeners to search boxes
        $("#searchTitle").on("keyup", function() {
            searchTable(0, this);
        });

        $("#searchLink").on("keyup", function() {
            searchTable(1, this);
        });

        $("#searchKeyword").on("keyup", function() {
            searchTable(2, this);
        });

        $("#searchDesc").on("keyup", function() {
            searchTable(3, this);
        });

        $("#searchImage").on("keyup", function() {
            searchTable(4, this);
        });
    });



    </script>
    
</body>

</html>
