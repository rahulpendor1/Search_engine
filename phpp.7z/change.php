<?php
// Start the session
session_start();
echo $MOB=$_SESSION["mobile"];
?>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="login.css">
      
        <title>
forgate password
        </title>
    </head>
    <body>
          <div class="center">
            <h1><u><b>
              <!-- <script>alert('OTP Verification Success');</script> -->
            </b></u> <br>
                Reset Password  
            </h1>
            <form action="#" method="POST" autocomplete="off">
            <div class="form">
                <input type="text" name="pass1" required placeholder="Please new password" 
                class="textbox" style="font-size:15px;">

             <input type="text" name="pass2" placeholder="Please confirm new password" class="textbox" 
             style="font-size:15px;">
               
             <input type="submit" name="change"  value="Change password" class="btn">
                <div class="signup" style="color:blue;"> <a href="login.php" class="link">Login Here
                      
                </a>&nbsp; &nbsp; <a href="sign.php" class="link">Signup Here</a></div>
            </div>
          </div>
        </form>




   

 

<?php      
include("connection.php");

      if (isset($_POST['change']))
      {
        
         $pass11 = $_POST['pass1'];
         $pass22 = $_POST['pass2'];
                      if ($pass11==$pass22)
                      {
                          $email=$_SESSION["username"];
                    // echo $email;
                    // echo "123";
                    $sql = "UPDATE info SET password='$pass11' WHERE email='$email'";
                      if ($conn->query($sql) === TRUE) 
                      {
                        //echo "Record updated successfully"; 
                        echo "<script>
                        alert('Password Changed successfully!');
                        window.location.href = 'login.php';
                             </script>";
                        
                      }      else{
                          echo "Dear".$_SESSION["username"]."please retry";
                          //  echo "<script>alert('Problem while change pass.');</script>";
                        }
                      }
      }

    
?>
 </script>





</body>




</html>