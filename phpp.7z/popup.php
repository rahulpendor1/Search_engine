<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Popup Example</title>
    <link rel="stylesheet" href="pop.css">
</head>

<body>
    <div id="popup" class="popup">
        <div class="popup-content">
            <span>Your password has been changed</span><br>
          <b> You can &nbsp;&nbsp;</b> <button id="popupButton">Login</button>&nbsp;&nbsp;<b>now.</b>
        </div>
    </div>

    <script src="pop.js"></script>
</body>

</html>
