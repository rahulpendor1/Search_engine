<?php
session_start();
$k=$_SESSION['username'];
if($k == true){

}
else{
    header('location:login.php');
}
?>
<html>
<head>
    <title>Display</title>
    <link rel="stylesheet" type="text/css" href="capanel.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
      body {
    margin: 0;
    padding: 0;
}

#navbar {
    background-color: black;
    padding: 10px 0;
    text-align: center;
}

#navbar ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
}

#navbar ul li {
    display: inline;
    margin-right: 20px;
}

#navbar ul li a {
    text-decoration: none;
    color: white;
    font-size: 18px;
}

#navbar ul li a:hover {
    color: green;
}

.c {
    background-color: lightblue;
    width: 80%;
    padding: 20px;
    border-radius: 10px;
}

.r {
    font-size: 25px;
}

.q {
    font-size: 20px;
}

.mainbox {
    margin-top: 20px;
}

/* Reset default table styles */
table {
    border-collapse: collapse;
    width: 100%;
    background-color: #e1b5ff;
}

/* Table header styles */
table th {
    background-color: orange;
    color: white;
    border: 2px solid #8800c7;
    padding: 10px;
    text-align: center;
}

/* Table row styles */
table tr {
    text-align: center;
}

/* Table cell styles */
table td {
    border: 2px solid #8800c7;
    padding: 10px;
}

/* Hover effect for table rows */
table tr:hover {
    background-color: green;
}
#export-buttons {
    margin-top: 20px;
    text-align: center;
}

#export-buttons button {
    background-color: green;
    color: white;
    border: none;
    padding: 10px 20px;
    margin: 0 10px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s ease;
}

      </style>

         <!-- Include jsPDF and xlsx libraries -->
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.3/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.0/xlsx.full.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.3/jspdf.umd.min.js"></script>

</head>
<body bgcolor="blueviolet">
    <span id="content">
        <div id="navbar">
            <ul>
                <li><a href="data.php">Open Website Data</a></li>
                <li><a href="addsite.php">Add New Website</a></li>
                <li><a href="index.php">Search Engine</a></li>
            </ul>
        </div>
        <br><br>
        <center>
            <div class="c">
                <tr>
                    <td class="r">
                        <b font-size="25px">Control Panel
                            <center>
                                <td class="q"><br>Admins Data </b></td>
                            </center>
                    </td>
                </tr>
            </div>
        </center><br>
        <div class="mainbox">
            <?php
            include("connection.php");
            error_reporting(0);

            $qqq="SELECT * FROM `info`";
            $rrr= mysqli_query($conn,$qqq);
            $aaa=mysqli_num_rows($rrr);

            if($aaa != 0) {
            ?>
            <center>
                <table border="1" cellspacing="5" width="90%" id="trid">
                <tr>
    <th><input type="text" id="searchName" placeholder="Search by Name"></th>
    <th><input type="text" id="searchMobile" placeholder="Search by Mobile"></th>
    <th><input type="text" id="searchEmail" placeholder="Search by Email"></th>
    <th><input type="text" id="searchUsername" placeholder="Search by Username"></th>
    <th><input type="text" id="searchPassword" placeholder="Search by Password"></th>
</tr>

                    <tr>
                        <th width='10%'>Name </th>
                        <th width='10%'>Mobile </th>
                        <th width='10%'>Email </th>
                        <th width='10%'>Username </th>
                        <th width='10%'>Password</th>
                    </tr>
                    <?php
                        while($result1=mysqli_fetch_assoc($rrr)) {
                            echo "<tr>
                                    <td >".$result1['name']."</td>
                                    <td >".$result1['mobile']."</td>
                                    <td>".$result1['email']."</td>
                                    <td>".$result1['username']."</td>
                                    <td>".$result1['password']."</td>
                                </tr>";
                        }
                    ?>
                </table>
            </center>
            <?php
            } else {
                echo "No data available.";
            }
            ?>
        </div>
    </span>
</body>



      <!-- Export buttons -->
      <div id="export-buttons">
 
        <button id="excel-button">Export to Excel</button>
        <br><br>
    </div>

    <!-- Your existing table and other content -->

    <script>
       
        document.getElementById('excel-button').addEventListener('click', exportToExcel);

        function exportToExcel() {
            const table = document.getElementById('trid'); // Replace 'your-table-id' with your actual table ID
            const ws = XLSX.utils.table_to_sheet(table);
            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
            XLSX.writeFile(wb, 'Admins.xlsx');
        }



        

    $(document).ready(function() {
        // Function to perform search based on input value and column index
        function searchTable(columnIndex, inputElement) {
            var filter, table, tr, td, i, txtValue;
            filter = inputElement.value.toUpperCase();
            table = document.getElementById("trid"); // Replace "trid" with your table's ID
            tr = table.getElementsByTagName("tr");

            for (i = 1; i < tr.length; i++) { // Start from 1 to skip the header row
                td = tr[i].getElementsByTagName("td")[columnIndex];
                if (td) {
                    txtValue = td.textContent || td.innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }
                }
            }
        }

        // Attach keyup event listeners to search boxes
        $("#searchName").on("keyup", function() {
            searchTable(0, this);
        });

        $("#searchMobile").on("keyup", function() {
            searchTable(1, this);
        });

        $("#searchEmail").on("keyup", function() {
            searchTable(2, this);
        });

        $("#searchUsername").on("keyup", function() {
            searchTable(3, this);
        });

        $("#searchPassword").on("keyup", function() {
            searchTable(4, this);
        });
    });
</script>

    
</html>
