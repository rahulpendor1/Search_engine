<?php 
include("bootloder.php")
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CPANEL - Modern Search</title>
    <meta name="description" content="Modern search interface with beautiful mountain landscape">
    <meta name="author" content="CPANEL">
    
    <!-- Preconnect to Google Fonts for better performance -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
            overflow-x: hidden;
        }

        .container {
            min-height: 100vh;
            position: relative;
            overflow: hidden;
        }

        /* Background Image with Overlay */
        .background {
            position: absolute;
            inset: 0;
            background-image: url('https://images.unsplash.com/photo-1470813740244-df37b8c1edcb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2071&q=80');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }

        .overlay {
            position: absolute;
            inset: 0;
            background: linear-gradient(to bottom, rgba(0,0,0,0.2), transparent, rgba(0,0,0,0.3));
        }

        /* Content */
        .content {
            position: relative;
            z-index: 10;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Header */
        .header {
            padding: 1.5rem;
        }

        .logo {
            color: #ef4444;
            font-weight: 700;
            font-size: 1.25rem;
            letter-spacing: 0.1em;
        }

        /* Main Content */
        .main {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0 1.5rem;
        }

        .search-container {
            width: 100%;
            max-width: 42rem;
            margin: 0 auto;
            text-align: center;
        }

        .search-section {
            display: flex;
            flex-direction: column;
            gap: 2rem;
        }

        .title {
            color: white;
            font-size: 1.875rem;
            font-weight: 300;
            margin-bottom: 2rem;
            letter-spacing: 0.025em;
        }

        .search-form {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }

        /* Search Input */
        .input-container {
            position: relative;
        }

        .search-input {
            width: 100%;
            height: 4rem;
            padding: 0 1.5rem;
            font-size: 1.125rem;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(12px);
            border: 2px solid rgba(255, 255, 255, 0.2);
            border-radius: 1rem;
            color: white;
            transition: all 0.3s ease;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
        }

        .search-input::placeholder {
            color: rgba(255, 255, 255, 0.7);
        }

        .search-input:focus {
            outline: none;
            border-color: rgba(255, 255, 255, 0.4);
            background: rgba(255, 255, 255, 0.15);
        }

        .input-gradient {
            position: absolute;
            inset: 0;
            border-radius: 1rem;
            background: linear-gradient(to right, transparent, rgba(255, 255, 255, 0.05), transparent);
            pointer-events: none;
        }

        /* Search Button */
        .search-button {
            width: 100%;
            padding: 1rem 3rem;
            font-size: 1.125rem;
            font-weight: 500;
            background: linear-gradient(to right, #c084fc, #f472b6, #a855f7);
            color: white;
            border: none;
            border-radius: 1rem;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }

        .search-button:hover {
            background: linear-gradient(to right, #a855f7, #ec4899, #9333ea);
            transform: scale(1.05);
            box-shadow: 0 25px 50px -12px rgba(168, 85, 247, 0.25);
        }

        .search-icon {
            width: 1.25rem;
            height: 1.25rem;
        }

        /* Quick Links */
        .quick-links {
            margin-top: 3rem;
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 1rem;
            color: rgba(255, 255, 255, 0.8);
        }

        .quick-link {
            padding: 0.5rem 1rem;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(4px);
            border: none;
            border-radius: 9999px;
            color: rgba(255, 255, 255, 0.8);
            font-size: 0.875rem;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .quick-link:hover {
            background: rgba(255, 255, 255, 0.2);
        }

        /* Footer */
        .footer {
            padding: 1.5rem;
            text-align: center;
        }

        .footer-text {
            color: rgba(255, 255, 255, 0.6);
            font-size: 0.875rem;
        }

        /* Floating Elements */
        .floating-dot {
            position: absolute;
            border-radius: 50%;
        }

        .dot-1 {
            top: 25%;
            left: 25%;
            width: 0.5rem;
            height: 0.5rem;
            background: rgba(255, 255, 255, 0.3);
            animation: pulse 2s infinite;
        }

        .dot-2 {
            top: 33%;
            right: 33%;
            width: 0.25rem;
            height: 0.25rem;
            background: rgba(255, 255, 255, 0.4);
            animation: pulse 2s infinite;
            animation-delay: 1s;
        }

        .dot-3 {
            bottom: 25%;
            left: 33%;
            width: 0.375rem;
            height: 0.375rem;
            background: rgba(255, 255, 255, 0.2);
            animation: pulse 2s infinite;
            animation-delay: 2s;
        }

        /* Animations */
        @keyframes pulse {
            0%, 100% {
                opacity: 1;
            }
            50% {
                opacity: 0.5;
            }
        }

        /* Responsive Design */
        @media (min-width: 640px) {
            .search-button {
                width: auto;
            }
        }

        @media (min-width: 768px) {
            .title {
                font-size: 1.875rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Background Image with Overlay -->
        <div class="background">
            <div class="overlay"></div>
        </div>

        <!-- Content -->
        <div class="content">
            <!-- Header -->
            <header class="header">
            <div class="logo">
    <a href="login.php" style="color:red; text-decoration: none;">CPANEL</a>
</div>
<div class="logo">
    <!-- <a href="login.php" style="color:red; text-decoration: none;">CPANEL</a>
      -->
      <p><span id="datetime" style="color:white;"></span></p>

</div>

                  
            </header>

            <!-- Main Content -->
            <main class="main">
                <div class="search-container">
                    <div class="search-section">
                        <h1 class="title">Search Here</h1>
                        
                        <form action="result.php" method="GET" class="search-form" id="searchForm">
                            <!-- Search Input -->
                            <div class="input-container">
                                <input
                                    type="text"
                                    placeholder="Enter your search query..."
                                    class="search-input"
                                    id="searchInput"
                                    name="searchbo"
                                >
                                <div class="input-gradient"></div>
                            </div>

                            <!-- Search Button -->
                            <button type="submit" class="search-button" name="searchbt">
                                <svg class="search-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m21 21-6-6m2-5a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z"/>
                                </svg>
                                Search
                            </button>
                        </form>

             
                </div>
            </main>

            <!-- Footer -->
            <footer class="footer">
                <p class="footer-text">© 2024 CPANEL. All rights reserved.</p>
            </footer>
        </div>

        <!-- Floating Elements -->
        <div class="floating-dot dot-1"></div>
        <div class="floating-dot dot-2"></div>
        <div class="floating-dot dot-3"></div>
    </div>




<script>
    function updateDateTime() {
        const now = new Date();

        // Format: DD-MM-YYYY HH:MM:SS
        const day = String(now.getDate()).padStart(2, '0');
        const month = String(now.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed
        const year = now.getFullYear();

        const hours = String(now.getHours()).padStart(2, '0');
        const minutes = String(now.getMinutes()).padStart(2, '0');
        const seconds = String(now.getSeconds()).padStart(2, '0');

        const formatted = `${day}-${month}-${year} ${hours}:${minutes}:${seconds}`;

        document.getElementById("datetime").textContent = formatted;
    }

    updateDateTime(); // Show immediately
    setInterval(updateDateTime, 1000); // Update every second
</script>

</body>
</html>
