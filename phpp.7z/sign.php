<?php
session_start();
?>
<html>
<head>
    <script>
        function userPresent() {
  alert("Admin Already Present");

  
}
        </script>
    <link rel="stylesheet" type="text/css" href="signup.css">
</head>   




<body>
    <div class="center">
        <h1>
            Signup
        </h1>
        <form action="#" method="POST" autocomplete="off">
        <div class="form"><div class="lable">Enter your name </div>
            <input type="text" name="box1" placeholder="Name" class="textbox">
            <div class="lable">Enter your mobile </div> <input type="number" name="box2" required placeholder="Mobile" class="textbox" >
            <div class="lable">Enter your email</div> <input type="email" name="box3" required placeholder="Email" class="textbox">

            

            <div class="lable">Choose a username</div> <input type="text" name="box4" required  placeholder="Username as you want" class="textbox">
            <div class="lable">Set any password</div><input type="password" name="box5" required placeholder="Set Password" class="textbox">

         <input type="submit" name="signup"  value="login" class="btn">
            <div class="signup"> Already Member ? <a href="login.php" class="link">login Here</a></div>
        </div>
      </div>
    </form>
</body>

</html>
<?php



include("connection.php");
      if (isset($_POST['signup']))
      {
         $b1 = $_POST['box1'];
         $b2 = $_POST['box2'];
        //mail
         $b3 = $_POST['box3'];
        //username
         $b4 = $_POST['box4'];
         $b5 = $_POST['box5'];

         $str1="SELECT * FROM `info` WHERE `email` = '$b3' OR `username` = '$b4'";
         $rr1=mysqli_query($conn,$str1);

         if(mysqli_num_rows($rr1)>=1){

          echo '<script>userPresent();</script>';
         }
         else{
            /////////////


            include("test.php");

            $_SESSION["namec"] = $b1;
            $_SESSION["mobc"] = $b2;
            $_SESSION["emailc"] = $b3;
            $_SESSION["userc"] = $b4;
            $_SESSION["passc"] = $b5;
            
            $randomNumber = rand(100000, 999999);
             //echo $randomNumber;
             //$otp=strval( $randomNumber ) ;

            $_SESSION["otps"] = $randomNumber;
           
              $to=$b3;
              $subject="OTP";
              $msg= "Your one time otp is ,$randomNumber";
              smtp_mailer($to,$subject, $msg);

         }



      }


         ?>