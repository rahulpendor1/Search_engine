<?php
//include('smtp/PHPMailerAutoload.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'C:/xampp/htdocs/phpp/composer/vendor/phpmailer/phpmailer/src/Exception.php';
require 'C:/xampp/htdocs/phpp/composer/vendor/phpmailer/phpmailer/src/PHPMailer.php';
require 'C:/xampp/htdocs/phpp/composer/vendor/phpmailer/phpmailer/src/SMTP.php';



echo smtp_mailer($to,$subject,$message);

function smtp_mailer($to,$subject, $msg){
	$mail = new PHPMailer(); 
	$mail->IsSMTP(); 
	$mail->SMTPAuth = true; 
	$mail->SMTPSecure = 'tls'; 
	$mail->Host = "smtp.gmail.com";
	$mail->Port = 587; 
	$mail->IsHTML(true);
	$mail->CharSet = 'UTF-8';
	//$mail->SMTPDebug = 2; 
	$mail->Username = "pendorr2@gmail.com";
	$mail->Password = "khpr wtfz ujcu jvmf";
	$mail->SetFrom("pendorr2@gmail.com");
	$mail->Subject = $subject;
	$mail->Body =$msg;
	$mail->AddAddress($to);
	$mail->SMTPOptions=array('ssl'=>array(
		'verify_peer'=>false,
		'verify_peer_name'=>false,
		'allow_self_signed'=>false
	));

   

    
		if($mail->Send()){
					//return 'Sent';
					// header('location:sign_otp.php');
					echo "<script>
					alert('OTP sent successfully!');
					window.location.href = 'sign_otp.php';
				</script>";
		}else{
			//echo $mail->ErrorInfo;
			echo "Please provide your correct email address";
		}
	
}
?>